
from fastapi import status,HTTPException,APIRouter,Depends
from . import schema,models
from sqlalchemy.orm import Session
from .database import get_connection
router= APIRouter(tags=[" User Insert ,Update, Delete"])

# add data to array
@router.post('/adduser')
def addUser(payload:schema.User,db:Session=Depends(get_connection)):
    postdata= models.UserApp(**payload.model_dump())
    db.add(postdata)
    db.commit()
    return {'message': postdata}

# delete the User
@router.delete('/deleteuser/{name}')
def deleteUserById(name:str,db:Session=Depends(get_connection)):
    findData=db.query(models.UserApp).filter(models.UserApp.uname == name).first()
    if findData == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="OOPS !! Given user ID not Found")
    db.delete(findData)
    db.commit()
    return {'message': 'User Found and deleted'}

#update user
@router.put('/updateuser/{id}')
def updateUserById(id:int,payload:schema.User):
    findData= searchUserForindex(id)

    if findData == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="OOPS !! Given user ID not Found")
    udata=payload.model_dump()
    udata['id']= id
    usersData[findData]= udata
    
    return {'message': 'User Found and updated'}



    






