
from fastapi import FastAPI
from . import DMLUsers,loadUsers,models
from .database import engine,get_connection



models.Base.metadata.create_all(bind=engine)
app= FastAPI()

app.include_router(DMLUsers.router)
app.include_router(loadUsers.router)

