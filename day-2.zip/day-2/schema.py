from pydantic import BaseModel

class User(BaseModel):
    uname:str
    email:str
    city:str